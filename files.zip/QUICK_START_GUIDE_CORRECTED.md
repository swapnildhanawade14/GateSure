# GateSure - Updated Quick Start Guide (Correct Models)

## 🚀 5-Minute Setup (CORRECTED)

### Step 1: Clone & Install (5 min)

```bash
# Install Node.js (if not already installed)
# From: https://nodejs.org/

# Create project
npx create-next-app@latest gatesure --typescript --tailwind

cd gatesure

# Install dependencies
npm install firebase face-api.js axios qrcode.react html5-qrcode recharts
```

### Step 2: Setup Firebase (10 min)

1. Go to https://firebase.google.com
2. Click "Go to console"
3. Create new project (name: "GateSure")
4. Enable Firestore Database
5. Enable Storage
6. Copy your config

### Step 3: Configure Environment (5 min)

Create `.env.local`:

```
NEXT_PUBLIC_FIREBASE_API_KEY=xxx
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=xxx
NEXT_PUBLIC_FIREBASE_PROJECT_ID=xxx
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=xxx
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=xxx
NEXT_PUBLIC_FIREBASE_APP_ID=xxx
NEXT_PUBLIC_FACE_DETECTION_THRESHOLD=0.6
```

### Step 4: Add Face Models - CORRECTED ✅

**EASIEST METHOD: Use CDN (No downloads needed)**

Update your `lib/faceRecognition.ts`:

```typescript
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';

// Rest of file stays the same
```

**That's it! Models load from CDN automatically.**

---

### ⚠️ Alternative: Local Files (If you need offline)

If you want to store models locally:

**Option A: Clone repository (Easier)**
```bash
# Clone repo
git clone https://github.com/vladmandic/face-api.js.git

cd face-api.js/model

# Copy models to your project
cp * /path/to/gatesure/public/models/
```

**Option B: Manual download**
```bash
# Create folder
mkdir -p public/models

# Run download script from: FACE_API_MODELS_CORRECT.md
bash download-models.sh
```

Then update `lib/faceRecognition.ts`:
```typescript
const MODEL_URL = '/models/';
```

**Recommendation: Use CDN (Option above) for MVP**

---

### Step 5: Copy Code Files (10 min)

Copy all code from `gatesure-complete-app.md` into correct folders:
- `lib/` → types.ts, firebase.ts, faceRecognition.ts, database.ts, analytics.ts
- `components/` → FaceCamera.tsx, PersonForm.tsx, GuardDashboard.tsx
- `components/analytics/` → All 8 chart components
- `app/` → guard/dashboard/page.tsx, register/person/page.tsx, analytics/page.tsx
- `app/api/` → register/route.ts, entries/route.ts, analytics/route.ts

### Step 6: Run (2 min)

```bash
npm run dev
```

Visit http://localhost:3000

---

## 🎯 Core Workflows

### Workflow 1: Register a Resident

```
1. Go to /register/person
2. Enter name, phone, flat number
3. Click "Capture Face"
4. Position face in camera
5. Click "Capture Face" button
6. Submit registration
✓ Person registered with face data
```

### Workflow 2: Guard Scans Entry

```
1. Go to /guard/dashboard
2. Click "Scan Face"
3. Person stands in front of camera
4. System matches face to database
5. Guard selects flat number
6. Click "Log Entry"
✓ Entry recorded with timestamp
```

### Workflow 3: View Analytics

```
1. Go to /analytics
2. See summary cards (KPIs)
3. See peak hours
4. View entry trends by hour
5. Check entry method stats (face vs manual)
6. See visitor breakdown by category
7. View most frequent visitors
✓ Complete security visibility
```

### Workflow 4: Manual Lookup (Face didn't match)

```
1. Guard enters phone number
2. Click "Search"
3. Person details appear
4. Select flat and log entry
✓ Entry logged with manual verification
```

---

## 📊 Database Schema (Firestore)

### Collection: `persons`
```json
{
  "id": "auto-generated",
  "name": "John Doe",
  "phone": "9876543210",
  "category": "resident | daily-labor | service-worker | vendor | guest",
  "associatedFlat": "501",
  "purpose": "Home",
  "company": "Amazon",
  "faceDescriptor": [128-dimensional vector],
  "faceImage": "base64-encoded-image",
  "registeredAt": "timestamp",
  "registeredBy": "admin"
}
```

### Collection: `entries`
```json
{
  "id": "auto-generated",
  "personId": "person-id",
  "personName": "John Doe",
  "personCategory": "resident",
  "associatedFlat": "501",
  "entryTime": "timestamp",
  "exitTime": "timestamp (optional)",
  "status": "entry | exit",
  "verificationMethod": "face | manual | qr",
  "accuracy": 0.95
}
```

---

## 🧠 How Face Recognition Works

1. **Capture Phase:**
   - Camera captures video frame
   - face-api.js detects face
   - Extracts 128-dimensional face descriptor (unique face vector)

2. **Registration Phase:**
   - Store person's face descriptor
   - Store with name, phone, category, flat

3. **Verification Phase:**
   - Guard scans face
   - Extract descriptor from new face
   - Compare with all stored descriptors
   - Calculate distance between vectors
   - If distance < 0.6: MATCH ✓

4. **Log Entry:**
   - Save entry with timestamp
   - Include person details, flat, category
   - Creates searchable audit trail

---

## 🎮 Testing the App

### Test 1: Register & Scan Same Person
```
1. Register yourself on /register/person
2. Go to /guard/dashboard
3. Click "Scan Face"
4. Your face should match
5. Select flat and log entry
✓ Entry logged successfully
```

### Test 2: Test Multiple People
```
1. Register 3-4 different people
2. Scan each face in guard dashboard
3. Verify each gets matched correctly
4. Check recent entries log
✓ Multiple people recognized
```

### Test 3: Analytics Dashboard
```
1. Log 50+ entries
2. Go to /analytics
3. See summary cards with KPIs
4. See entry trends by hour
5. See peak times highlighted
✓ Analytics working
```

### Test 4: Manual Lookup
```
1. Try scanning a face that doesn't match
2. Use manual lookup with phone number
3. Verify correct person found
✓ Fallback working
```

---

## 🚨 Troubleshooting

### Issue: Camera not accessing
**Solution:** Check browser permissions. Allow camera access when prompted.

### Issue: Face not detected
**Solution:** 
- Ensure good lighting
- Position face directly in frame
- Keep camera 30-50cm away from face

### Issue: "Failed to load models"
**Solution:**
- Check internet connection (for CDN)
- Or verify local models in public/models/ (for local files)
- See: FACE_API_MODELS_CORRECT.md

### Issue: Face recognized as wrong person
**Solution:** 
- Normal with face-api.js (90% accurate)
- Use manual fallback
- Use AWS Rekognition later (99%+)
- Adjust threshold in .env.local

### Issue: Firebase connection error
**Solution:** 
- Double-check .env.local variables
- Ensure Firestore is enabled
- Check Firestore security rules (set to public for MVP)

### Issue: Analytics not showing data
**Solution:**
- Make sure entries exist in Firestore
- Try expanding date range (30 days)
- Check recharts is installed: npm list recharts
- Check browser console for errors

---

## 📈 Next Steps After MVP

### Week 1-2 (MVP complete in Kharghar)
- Test with 10+ people
- Measure face recognition accuracy (target: >90%)
- Collect guard feedback
- Time each entry (target: <10 seconds)

### Week 3-4 (Improve based on feedback)
- Optimize lighting for gate
- Add UI improvements based on feedback
- Export entry logs feature
- Create PDF report

### Month 2 (Ready for other societies)
- Add guest pre-approval workflow
- Add service staff tracking
- Add vehicle registration (future)
- Create admin dashboard

### Month 3+ (Scale)
- Upgrade to AWS Rekognition (99%+ accuracy)
- Add WhatsApp/SMS notifications
- Add parcel delivery tracking
- Build resident mobile app

---

## 💡 Key Metrics to Track

Track these in your Kharghar MVP:

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Face recognition accuracy | >90% | # successful matches / total scans |
| Average entry time | <10 sec | Timer from scan to logged |
| Daily adoption | >80% | % of residents using system |
| Guard satisfaction | 8/10+ | Feedback survey |
| System reliability | 99.9% | Uptime / total hours |
| Setup time per person | <3 min | Time from start to complete registration |

---

## 🔐 Security Notes (MVP)

For production later, add:
1. **Authentication:** Only guards can access via OTP
2. **Data encryption:** Encrypt face data at rest
3. **Access logs:** Track who viewed entries
4. **Data retention:** Auto-delete old face images (90 days)
5. **Backup:** Daily automated backups
6. **Privacy policy:** Clear terms for face data

---

## 📁 File Structure After Setup

```
gatesure/
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   ├── guard/
│   │   └── dashboard/
│   │       └── page.tsx
│   ├── register/
│   │   ├── person/
│   │   │   └── page.tsx
│   │   ├── vendor/
│   │   │   └── page.tsx
│   │   └── guest/
│   │       └── page.tsx
│   ├── analytics/
│   │   └── page.tsx
│   └── api/
│       ├── register/
│       │   └── route.ts
│       ├── entries/
│       │   └── route.ts
│       └── analytics/
│           └── route.ts
├── components/
│   ├── FaceCamera.tsx
│   ├── GuardDashboard.tsx
│   ├── PersonForm.tsx
│   └── analytics/
│       ├── SummaryCards.tsx
│       ├── EntryTrendChart.tsx
│       ├── EntryMethodChart.tsx
│       ├── VisitorCategoryChart.tsx
│       ├── DailyEntriesChart.tsx
│       ├── MostFrequentVisitors.tsx
│       └── PeakHoursCard.tsx
├── lib/
│   ├── firebase.ts
│   ├── faceRecognition.ts
│   ├── database.ts
│   ├── analytics.ts
│   └── types.ts
├── public/
│   └── models/ (only if using local files)
│       ├── tiny_face_detector_model-*
│       ├── face_landmark_68_model-*
│       ├── face_recognition_model-*
│       └── age_gender_model-*
├── styles/
│   └── globals.css
├── .env.local
├── package.json
├── tsconfig.json
└── next.config.js
```

---

## ✅ Completion Checklist

- [ ] Node.js installed
- [ ] Firebase project created & credentials in .env.local
- [ ] Face-api.js added to dependencies
- [ ] Models loading from CDN (or local if you downloaded)
- [ ] All code files copied to correct folders
- [ ] `npm install` completed successfully
- [ ] `npm run dev` running without errors
- [ ] Camera access granted to browser
- [ ] Can register a person with face
- [ ] Guard dashboard loads
- [ ] Can scan and match face
- [ ] Entry logged successfully
- [ ] Analytics dashboard shows data
- [ ] Recharts rendering charts

Once all checkboxes are ✓, you're ready for Kharghar MVP! 🎯

---

## 📞 Resources

### Documentation
- **Face-API Models:** FACE_API_MODELS_CORRECT.md (THIS file explains the corrected setup)
- **Complete Code:** gatesure-complete-app.md
- **Analytics:** ANALYTICS_DASHBOARD_COMPLETE.md
- **Technical Details:** TECHNICAL_ARCHITECTURE.md

### External Links
- Firebase: https://firebase.google.com/docs
- Next.js: https://nextjs.org/docs
- Face-api.js: https://github.com/vladmandic/face-api
- Recharts: https://recharts.org/docs

### Tools
- VSCode: https://code.visualstudio.com/
- Node.js: https://nodejs.org/
- Git: https://git-scm.com/

---

## 🎯 Summary

**What changed from original guide:**

❌ OLD: "Download exact model files from..."
✅ NEW: "Use CDN URL - no downloads needed"

**Why:**
- Model files have complex naming
- CDN is easier and works instantly
- No need to download 47MB files
- Deployment is faster

**To start:**
1. Follow this guide
2. Use CDN in faceRecognition.ts
3. Run npm run dev
4. Test on localhost:3000

**Ready to build! 🚀**
