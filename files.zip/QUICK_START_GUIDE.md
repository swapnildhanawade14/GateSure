# GateSure - Quick Start Guide

## 🚀 5-Minute Setup

### Step 1: Clone & Install (5 min)

```bash
# Install Node.js (if not already installed)
# From: https://nodejs.org/

# Create project
npx create-next-app@latest gatesure --typescript --tailwind

cd gatesure

# Install dependencies
npm install firebase face-api.js axios qrcode.react html5-qrcode
```

### Step 2: Setup Firebase (10 min)

1. Go to https://firebase.google.com
2. Click "Go to console"
3. Create new project (name: "GateSure")
4. Enable Firestore Database
5. Enable Storage
6. Copy your config

### Step 3: Configure Environment (5 min)

Create `.env.local`:

```
NEXT_PUBLIC_FIREBASE_API_KEY=xxx
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=xxx
NEXT_PUBLIC_FIREBASE_PROJECT_ID=xxx
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=xxx
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=xxx
NEXT_PUBLIC_FIREBASE_APP_ID=xxx
NEXT_PUBLIC_FACE_DETECTION_THRESHOLD=0.6
```

### Step 4: Add Face Models (5 min)

Download from: https://github.com/vladmandic/face-api/tree/master/model

Place files in `public/models/`:
- `tiny_face_detector_model-weights_manifest.json`
- `tiny_face_detector_model-shard1`
- `face_landmark_68_model-weights_manifest.json`
- `face_landmark_68_model-shard1`
- `face_recognition_model-weights_manifest.json`
- `face_recognition_model-shard1`
- `age_gender_model-weights_manifest.json`
- `age_gender_model-shard1`

### Step 5: Copy Code Files (10 min)

Copy all code from `gatesure-complete-app.md` into respective folders:
- `lib/` → types.ts, firebase.ts, faceRecognition.ts, database.ts
- `components/` → FaceCamera.tsx, PersonForm.tsx, GuardDashboard.tsx
- `app/` → guard/dashboard/page.tsx, register/person/page.tsx
- `app/api/` → register/route.ts, entries/route.ts

### Step 6: Run (2 min)

```bash
npm run dev
```

Visit http://localhost:3000

---

## 🎯 Core Workflows

### Workflow 1: Register a Resident

```
1. Go to /register/person
2. Enter name, phone, flat number
3. Click "Capture Face"
4. Position face in camera
5. Click "Capture Face" button
6. Submit registration
```

### Workflow 2: Guard Scans Entry

```
1. Go to /guard/dashboard
2. Click "Scan Face"
3. Person stands in front of camera
4. System matches face to database
5. Guard selects flat number
6. Click "Log Entry"
7. Entry is recorded with timestamp
```

### Workflow 3: Manual Lookup (if face recognition fails)

```
1. Guard enters phone number
2. Click "Search"
3. Person details appear
4. Select flat and log entry
```

---

## 📊 Database Schema (Firestore)

### Collection: `persons`
```
{
  id: "auto-generated",
  name: "John Doe",
  phone: "9876543210",
  category: "resident" | "daily-labor" | "service-worker" | "vendor" | "guest",
  associatedFlat: "501",
  purpose: "Maid",
  company: "Amazon",
  faceDescriptor: Float32Array, // 128-dimensional vector
  faceImage: "data:image/jpeg;base64,...",
  registeredAt: Timestamp,
  registeredBy: "admin"
}
```

### Collection: `entries`
```
{
  id: "auto-generated",
  personId: "person-doc-id",
  personName: "John Doe",
  personCategory: "resident",
  associatedFlat: "501",
  entryTime: Timestamp,
  exitTime: Timestamp (optional),
  purpose: "Home",
  status: "entry" | "exit",
  verificationMethod: "face" | "manual" | "qr",
  accuracy: 0.95
}
```

---

## 🔧 Component Overview

### 1. FaceCamera.tsx
- Accesses device camera
- Captures face and extracts face descriptor
- Returns 128-dimensional face vector

### 2. PersonForm.tsx
- Registration form for any person type
- Integrated camera for face capture
- Saves to Firestore with face descriptor

### 3. GuardDashboard.tsx
- Real-time camera feed
- Face scanning & matching
- Manual phone lookup
- Entry logging
- Recent entries display

---

## 🧠 How Face Recognition Works

1. **Capture Phase:**
   - Camera captures video frame
   - face-api.js detects face in frame
   - Extracts 128-dimensional face descriptor (unique face vector)

2. **Registration Phase:**
   - Store person's name, phone, category, flat
   - Store their face descriptor (128 numbers)

3. **Verification Phase:**
   - Guard scans face
   - Extract descriptor from new face
   - Compare with all stored descriptors
   - Calculate distance between vectors
   - If distance < threshold (0.6): MATCH ✓

4. **Log Entry:**
   - If matched, save entry with timestamp
   - Include person details, flat, category
   - Creates searchable audit trail

---

## 🎮 Testing the App

### Test Scenario 1: Register & Scan Same Person
```
1. Register yourself on /register/person
2. Go to /guard/dashboard
3. Click "Scan Face"
4. Your face should be recognized as "You"
5. Select flat and log entry
```

### Test Scenario 2: Test Multiple People
```
1. Register 3-4 different people
2. Scan each face in guard dashboard
3. Verify each gets matched correctly
4. Check recent entries log
```

### Test Scenario 3: Test Manual Lookup
```
1. Scan face that doesn't match anyone
2. Use manual lookup with phone number
3. Verify correct person found
```

---

## 🚨 Troubleshooting

### Issue: Camera not accessing
**Solution:** Check browser permissions. Allow camera access when prompted.

### Issue: Face not detected
**Solution:** 
- Ensure good lighting
- Position face directly in frame
- Keep camera 30-50cm away from face

### Issue: Face recognized as wrong person
**Solution:** This is normal with face-api.js. 
- Retrain with better photos
- Adjust threshold in .env.local (lower = stricter)
- Upgrade to AWS Rekognition for better accuracy

### Issue: Firebase connection error
**Solution:** 
- Double-check .env.local variables
- Ensure Firestore is enabled in Firebase Console
- Check Firestore security rules (set to public for MVP)

### Issue: Models not loading
**Solution:** 
- Download models from GitHub link above
- Place in `public/models/` folder
- Restart dev server

---

## 📈 Next Steps After MVP

### Week 1-2 (MVP complete in Kharghar)
- Test with 10+ people
- Measure face recognition accuracy
- Collect guard feedback
- Document pain points

### Week 3-4 (Improve based on feedback)
- Optimize lighting for gate environment
- Add manual fallback UI improvements
- Implement entry logs export
- Create admin dashboard

### Month 2 (Ready for other societies)
- Add guest pre-approval workflow
- Implement service staff tracking
- Add vehicle registration
- Create analytics dashboard

### Month 3+ (Scale)
- Upgrade to AWS Rekognition (99%+ accuracy)
- Add WhatsApp/SMS notifications
- Implement parcel delivery tracking
- Build resident mobile app

---

## 💡 Key Metrics to Track

Track these in your Kharghar MVP:

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Face recognition accuracy | >90% | # successful matches / total scans |
| Average entry time | <10 sec | Timer from scan to logged |
| Daily adoption | >80% | % of residents using system vs manual |
| Guard satisfaction | 8/10+ | Feedback survey |
| System reliability | 99.9% | Uptime / total hours |
| Average setup time per person | <3 min | Time from start to complete registration |

---

## 🔐 Security Notes (MVP)

For production, add:
1. **Authentication:** Only authenticated guards can access
2. **Data encryption:** Encrypt face data at rest
3. **Access logs:** Track who viewed which entries
4. **Data retention:** Auto-delete old face images (90 days)
5. **Backup:** Daily automated backups
6. **Privacy policy:** Clear terms for face data usage

---

## 📞 Support

### Resources
- Face-api.js docs: https://github.com/vladmandic/face-api
- Firebase docs: https://firebase.google.com/docs
- Next.js docs: https://nextjs.org/docs
- Tailwind CSS: https://tailwindcss.com/docs

### Common Issues
1. Google "face-api.js [your issue]"
2. Check Firebase console for errors
3. Look at browser console (F12 > Console tab)
4. Check network tab for API failures

---

## ✅ Completion Checklist

- [ ] Node.js installed
- [ ] Firebase project created & credentials copied
- [ ] `.env.local` file created with Firebase config
- [ ] Face-api models downloaded to `public/models/`
- [ ] All code files copied to correct folders
- [ ] `npm install` completed
- [ ] `npm run dev` running without errors
- [ ] Camera access granted to browser
- [ ] Can register a person with face
- [ ] Guard dashboard can scan and match face
- [ ] Entry logged successfully

Once all checkboxes are ✓, you're ready for Kharghar MVP!

---

**Good luck! You're building the future of residential security. 🚀**
