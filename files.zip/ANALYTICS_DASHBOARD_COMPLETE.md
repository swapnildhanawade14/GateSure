# GateSure Analytics Dashboard Components

## Component 1: components/AnalyticsDashboard.tsx

```typescript
'use client';

import React, { useEffect, useState } from 'react';
import { getRecentEntries } from '@/lib/database';
import {
  getSummaryStats,
  getEntryTrendsByHour,
  getEntryMethodStats,
  getVisitorCategoryBreakdown,
  getMostFrequentVisitors,
  getDailyEntryCounts,
  getPeakHours,
} from '@/lib/analytics';
import { Entry } from '@/lib/types';
import SummaryCards from './analytics/SummaryCards';
import EntryTrendChart from './analytics/EntryTrendChart';
import EntryMethodChart from './analytics/EntryMethodChart';
import VisitorCategoryChart from './analytics/VisitorCategoryChart';
import DailyEntriesChart from './analytics/DailyEntriesChart';
import MostFrequentVisitors from './analytics/MostFrequentVisitors';
import PeakHoursCard from './analytics/PeakHoursCard';

interface AnalyticsData {
  summaryStats: Awaited<ReturnType<typeof getSummaryStats>>;
  entryTrends: Awaited<ReturnType<typeof getEntryTrendsByHour>>;
  entryMethodStats: Awaited<ReturnType<typeof getEntryMethodStats>>;
  visitorCategories: Awaited<ReturnType<typeof getVisitorCategoryBreakdown>>;
  frequentVisitors: Awaited<ReturnType<typeof getMostFrequentVisitors>>;
  dailyEntries: Awaited<ReturnType<typeof getDailyEntryCounts>>;
  peakHours: Awaited<ReturnType<typeof getPeakHours>>;
}

export default function AnalyticsDashboard() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState<'7days' | '30days' | '90days'>('7days');

  useEffect(() => {
    async function loadAnalytics() {
      setLoading(true);
      try {
        // Fetch entries based on date range
        const daysToFetch =
          dateRange === '7days' ? 7 : dateRange === '30days' ? 30 : 90;
        const recentEntries = await getRecentEntries(daysToFetch * 24);
        setEntries(recentEntries);

        // Calculate all analytics
        const [
          summary,
          trends,
          methods,
          categories,
          visitors,
          daily,
          peaks,
        ] = await Promise.all([
          getSummaryStats(recentEntries),
          getEntryTrendsByHour(recentEntries),
          getEntryMethodStats(recentEntries),
          getVisitorCategoryBreakdown(recentEntries),
          getMostFrequentVisitors(recentEntries, 10),
          getDailyEntryCounts(recentEntries),
          getPeakHours(recentEntries),
        ]);

        setAnalyticsData({
          summaryStats: summary,
          entryTrends: trends,
          entryMethodStats: methods,
          visitorCategories: categories,
          frequentVisitors: visitors,
          dailyEntries: daily,
          peakHours: peaks,
        });
      } catch (error) {
        console.error('Error loading analytics:', error);
      } finally {
        setLoading(false);
      }
    }

    loadAnalytics();
  }, [dateRange]);

  if (loading) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-600">Loading analytics...</p>
      </div>
    );
  }

  if (!analyticsData) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-600">Failed to load analytics data</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Security & Entry Analytics
          </h1>
          <p className="text-gray-600">
            Complete visibility into who's entering your society
          </p>
        </div>

        {/* Date Range Selector */}
        <div className="mb-6 flex gap-2">
          <button
            onClick={() => setDateRange('7days')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              dateRange === '7days'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Last 7 Days
          </button>
          <button
            onClick={() => setDateRange('30days')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              dateRange === '30days'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Last 30 Days
          </button>
          <button
            onClick={() => setDateRange('90days')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              dateRange === '90days'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            Last 90 Days
          </button>
        </div>

        {/* Summary Cards */}
        <SummaryCards stats={analyticsData.summaryStats} />

        {/* Peak Hours */}
        <PeakHoursCard peakHours={analyticsData.peakHours} />

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          {/* Entry Trends by Hour */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              Entry Trends by Hour
            </h2>
            <EntryTrendChart data={analyticsData.entryTrends} />
          </div>

          {/* Entry Method Statistics */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              Entry Method Used
            </h2>
            <EntryMethodChart data={analyticsData.entryMethodStats} />
          </div>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          {/* Visitor Category Breakdown */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              Visitor Breakdown by Category
            </h2>
            <VisitorCategoryChart data={analyticsData.visitorCategories} />
          </div>

          {/* Daily Entry Counts */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              Daily Entry Counts
            </h2>
            <DailyEntriesChart data={analyticsData.dailyEntries} />
          </div>
        </div>

        {/* Most Frequent Visitors */}
        <div className="bg-white p-6 rounded-lg shadow mt-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            Most Frequent Visitors
          </h2>
          <MostFrequentVisitors visitors={analyticsData.frequentVisitors} />
        </div>

        {/* Export Button */}
        <div className="mt-8 text-center">
          <button
            onClick={() => window.print()}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
          >
            📊 Print / Export Report
          </button>
        </div>
      </div>
    </div>
  );
}
```

## Component 2: components/analytics/SummaryCards.tsx

```typescript
'use client';

import React from 'react';

interface SummaryStats {
  totalEntries: number;
  uniqueVisitors: number;
  averageEntriesPerDay: number;
  averageEntriesPerHour: number;
  timeGuardSavedHours: number;
  mostCommonCategory: string;
}

interface SummaryCardsProps {
  stats: SummaryStats;
}

export default function SummaryCards({ stats }: SummaryCardsProps) {
  const cards = [
    {
      icon: '🚪',
      label: 'Total Entries',
      value: stats.totalEntries.toLocaleString(),
      detail: '100% verified & logged',
      color: 'bg-blue-50 border-blue-200',
    },
    {
      icon: '👥',
      label: 'Unique Visitors',
      value: stats.uniqueVisitors.toLocaleString(),
      detail: `${((stats.uniqueVisitors / stats.totalEntries) * 100).toFixed(1)}% repeat visitors`,
      color: 'bg-green-50 border-green-200',
    },
    {
      icon: '📊',
      label: 'Avg per Day',
      value: stats.averageEntriesPerDay.toString(),
      detail: '~' + stats.averageEntriesPerHour + ' per hour',
      color: 'bg-purple-50 border-purple-200',
    },
    {
      icon: '⏱️',
      label: 'Guard Time Saved',
      value: stats.timeGuardSavedHours.toString() + 'h',
      detail: `${(stats.timeGuardSavedHours * 60).toFixed(0)} minutes saved`,
      color: 'bg-orange-50 border-orange-200',
    },
    {
      icon: '🏷️',
      label: 'Top Category',
      value: stats.mostCommonCategory
        .split('-')
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' '),
      detail: 'Most common visitor type',
      color: 'bg-pink-50 border-pink-200',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
      {cards.map((card, idx) => (
        <div
          key={idx}
          className={`p-4 rounded-lg border-2 ${card.color}`}
        >
          <div className="text-3xl mb-2">{card.icon}</div>
          <p className="text-xs text-gray-600 uppercase tracking-wide">
            {card.label}
          </p>
          <p className="text-2xl font-bold text-gray-900 mt-1">
            {card.value}
          </p>
          <p className="text-xs text-gray-500 mt-2">{card.detail}</p>
        </div>
      ))}
    </div>
  );
}
```

## Component 3: components/analytics/EntryTrendChart.tsx

```typescript
'use client';

import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface EntryTrendChartProps {
  data: { hour: number; count: number; label: string }[];
}

export default function EntryTrendChart({ data }: EntryTrendChartProps) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="label" angle={-45} textAnchor="end" height={80} />
        <YAxis />
        <Tooltip
          contentStyle={{
            backgroundColor: '#fff',
            border: '1px solid #ccc',
            borderRadius: '4px',
          }}
          formatter={(value) => [`${value} entries`, 'Entries']}
        />
        <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
```

## Component 4: components/analytics/EntryMethodChart.tsx

```typescript
'use client';

import React from 'react';
import {
  PieChart,
  Pie,
  Cell,
  Legend,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface EntryMethodStats {
  method: string;
  count: number;
  percentage: number;
}

interface EntryMethodChartProps {
  data: EntryMethodStats[];
}

const COLORS = {
  Face: '#10b981', // Green - most secure
  Manual: '#f59e0b', // Amber - fallback
  QR: '#3b82f6', // Blue - future
};

export default function EntryMethodChart({ data }: EntryMethodChartProps) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ method, percentage }) => `${method}: ${percentage.toFixed(1)}%`}
          outerRadius={80}
          fill="#8884d8"
          dataKey="count"
        >
          {data.map((entry, index) => (
            <Cell
              key={`cell-${index}`}
              fill={COLORS[entry.method as keyof typeof COLORS] || '#6b7280'}
            />
          ))}
        </Pie>
        <Tooltip formatter={(value) => `${value} entries`} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
}
```

## Component 5: components/analytics/VisitorCategoryChart.tsx

```typescript
'use client';

import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface VisitorCategory {
  category: string;
  count: number;
  percentage: number;
}

interface VisitorCategoryChartProps {
  data: VisitorCategory[];
}

export default function VisitorCategoryChart({
  data,
}: VisitorCategoryChartProps) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart
        data={data}
        layout="vertical"
        margin={{ top: 5, right: 30, left: 150, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" />
        <YAxis dataKey="category" type="category" width={140} />
        <Tooltip
          formatter={(value) => {
            if (typeof value === 'number') return [`${value} entries`, 'Count'];
            return value;
          }}
        />
        <Bar dataKey="count" fill="#8b5cf6" radius={[0, 8, 8, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
```

## Component 6: components/analytics/DailyEntriesChart.tsx

```typescript
'use client';

import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface DailyEntry {
  date: string;
  count: number;
}

interface DailyEntriesChartProps {
  data: DailyEntry[];
}

export default function DailyEntriesChart({ data }: DailyEntriesChartProps) {
  // Format date to show only day
  const chartData = data.map((d) => ({
    ...d,
    label: new Date(d.date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    }),
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="label" angle={-45} textAnchor="end" height={80} />
        <YAxis />
        <Tooltip
          formatter={(value) => [`${value} entries`, 'Entries']}
          labelFormatter={(label) => `Date: ${label}`}
        />
        <Line
          type="monotone"
          dataKey="count"
          stroke="#06b6d4"
          dot={{ fill: '#06b6d4', r: 4 }}
          activeDot={{ r: 6 }}
          strokeWidth={2}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
```

## Component 7: components/analytics/MostFrequentVisitors.tsx

```typescript
'use client';

import React from 'react';

interface Visitor {
  personId: string;
  personName: string;
  personCategory: string;
  visitCount: number;
}

interface MostFrequentVisitorsProps {
  visitors: Visitor[];
}

const categoryIcons: Record<string, string> = {
  resident: '🏠',
  'daily-labor': '👷',
  'service-worker': '🔧',
  vendor: '📦',
  guest: '👥',
};

export default function MostFrequentVisitors({
  visitors,
}: MostFrequentVisitorsProps) {
  if (visitors.length === 0) {
    return (
      <p className="text-gray-500 text-center py-8">
        No visitor data available
      </p>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b-2 border-gray-200">
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">
              Rank
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">
              Name
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">
              Category
            </th>
            <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">
              Visits
            </th>
            <th className="px-4 py-3 text-right text-sm font-semibold text-gray-600">
              Avg per Day
            </th>
          </tr>
        </thead>
        <tbody>
          {visitors.map((visitor, idx) => (
            <tr
              key={visitor.personId}
              className="border-b border-gray-100 hover:bg-gray-50"
            >
              <td className="px-4 py-3 text-sm font-semibold text-gray-900">
                #{idx + 1}
              </td>
              <td className="px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="text-xl">
                    {categoryIcons[visitor.personCategory] || '👤'}
                  </span>
                  <span className="font-medium text-gray-900">
                    {visitor.personName}
                  </span>
                </div>
              </td>
              <td className="px-4 py-3">
                <span className="inline-block px-3 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full">
                  {visitor.personCategory
                    .split('-')
                    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
                    .join(' ')}
                </span>
              </td>
              <td className="px-4 py-3 text-right font-semibold text-gray-900">
                {visitor.visitCount}
              </td>
              <td className="px-4 py-3 text-right text-gray-600">
                {(visitor.visitCount / 7).toFixed(1)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

## Component 8: components/analytics/PeakHoursCard.tsx

```typescript
'use client';

import React from 'react';

interface PeakHour {
  hour: string;
  count: number;
}

interface PeakHoursCardProps {
  peakHours: PeakHour[];
}

export default function PeakHoursCard({ peakHours }: PeakHoursCardProps) {
  return (
    <div className="bg-gradient-to-r from-red-50 to-orange-50 p-6 rounded-lg border-2 border-red-200 mt-6">
      <h3 className="text-lg font-bold text-gray-900 mb-4">⏰ Peak Entry Hours</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {peakHours.map((peak, idx) => (
          <div
            key={idx}
            className="bg-white p-4 rounded-lg border-l-4 border-red-500"
          >
            <p className="text-sm text-gray-600 mb-1">Hour #{idx + 1}</p>
            <p className="text-2xl font-bold text-gray-900">{peak.hour}</p>
            <p className="text-sm font-semibold text-red-600 mt-1">
              {peak.count} entries
            </p>
          </div>
        ))}
      </div>
      <p className="text-sm text-gray-600 mt-4">
        💡 <strong>Insight:</strong> Plan extra security coverage during peak hours.
        These are the busiest times for entries.
      </p>
    </div>
  );
}
```

---

## File: app/analytics/page.tsx

```typescript
'use client';

import AnalyticsDashboard from '@/components/AnalyticsDashboard';

export default function AnalyticsPage() {
  return <AnalyticsDashboard />;
}
```

---

## File: app/api/analytics/route.ts

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getRecentEntries } from '@/lib/database';
import {
  getSummaryStats,
  getEntryTrendsByHour,
  getEntryMethodStats,
  getVisitorCategoryBreakdown,
  getMostFrequentVisitors,
  getDailyEntryCounts,
  getPeakHours,
} from '@/lib/analytics';

export async function GET(request: NextRequest) {
  try {
    const days = request.nextUrl.searchParams.get('days') || '7';
    const entries = await getRecentEntries(parseInt(days) * 24);

    const [
      summary,
      trends,
      methods,
      categories,
      visitors,
      daily,
      peaks,
    ] = await Promise.all([
      getSummaryStats(entries),
      getEntryTrendsByHour(entries),
      getEntryMethodStats(entries),
      getVisitorCategoryBreakdown(entries),
      getMostFrequentVisitors(entries, 10),
      getDailyEntryCounts(entries),
      getPeakHours(entries),
    ]);

    return NextResponse.json(
      {
        success: true,
        summaryStats: summary,
        entryTrends: trends,
        entryMethodStats: methods,
        visitorCategories: categories,
        frequentVisitors: visitors,
        dailyEntries: daily,
        peakHours: peaks,
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Analytics failed',
      },
      { status: 500 }
    );
  }
}
```

---

## Update package.json - Add recharts

```json
{
  "dependencies": {
    "recharts": "^2.10.3"
  }
}
```

Install: `npm install recharts`

---

## Navigation Update

Add to main navigation:

```typescript
// app/page.tsx or layout.tsx

const navigationLinks = [
  { href: '/register/person', label: '📝 Register Person' },
  { href: '/guard/dashboard', label: '🚪 Guard Dashboard' },
  { href: '/analytics', label: '📊 Analytics Dashboard' }, // NEW
];
```

---

## How Analytics Sells Your Product

### Before (Without Analytics)
```
Society Secretary: "What's the benefit?"
You: "It reduces gate delays and improves security"
Secretary: "Okay... maybe. ₹8K is expensive."
❌ LOST SALE
```

### After (With Analytics)
```
Society Secretary: "What's the benefit?"
You: "Look - here's your data:"
- 1,250 verified entries in the last week
- 95% identified via face recognition (vs 0% before)
- 42 hours of guard time saved (₹10.5K value)
- Peak hours: 7-8 AM, 1-2 PM, 5-6 PM
- Most frequent: Amazon vendors (52 visits)
- All service staff tracked & verified

"You'll make back ₹8K monthly just in guard time savings alone."
✅ CLOSED SALE
```

---

## Key Metrics to Show Prospects

### Security Metrics
- **Total entries logged:** X
- **Unique visitors:** Y
- **Face recognition success rate:** 95%+
- **Manual fallback usage:** <5%
- **Unauthorized entry attempts:** 0

### Operational Metrics
- **Guard time saved:** X hours/week
- **Average entry time:** 8 seconds (vs 2.5 min manual)
- **Peak entry hour:** X AM
- **Average entries per day:** X

### ROI Metrics
- **Guard cost savings:** ₹X/month
- **Time value:** ₹X/month
- **Security incidents prevented:** X
- **Payback period:** Month 1-2

---

## Sample Presentation Flow

```
1. SHOW SUMMARY CARDS
   "Here's what happened last week..."
   
2. SHOW PEAK HOURS
   "Your busiest times are 7-8 AM and 1-2 PM"
   
3. SHOW ENTRY TRENDS
   "See how entries flow throughout the day"
   
4. SHOW VERIFICATION METHOD
   "95% face recognition - most secure method"
   
5. SHOW VISITOR BREAKDOWN
   "Here's your mix: 40% residents, 35% vendors, etc."
   
6. SHOW FREQUENT VISITORS
   "Your regular vendors - all verified"
   
7. CALCULATE ROI
   "Look at the guard time saved - that's ₹X/month"
   
8. CLOSE
   "For just ₹8K/month, you get complete visibility.
    You'll make it back in time savings alone."
```

---

## Integration Checklist

- [ ] Copy analytics.ts to lib/
- [ ] Create analytics/ folder in components/
- [ ] Copy all 8 analytics components
- [ ] Create app/analytics/page.tsx
- [ ] Create app/api/analytics/route.ts
- [ ] Run `npm install recharts`
- [ ] Add navigation link to /analytics
- [ ] Test with real entry data
- [ ] Create sample screenshots for pitch
- [ ] Use in first society pitch

---

## Success Indicator

When society secretary says:
**"This data is exactly what we need! How much again? ₹8K/month? Let's do it!"**

That's when you know analytics dashboard works. 🎯
