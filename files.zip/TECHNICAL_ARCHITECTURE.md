# GateSure - Technical Architecture & System Design

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         Frontend (Browser)                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Next.js + React + Tailwind CSS                          │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  Guard Dashboard                                 │   │  │
│  │  │  - Real-time camera feed                         │   │  │
│  │  │  - Face scan button                              │   │  │
│  │  │  - Matched person display                        │   │  │
│  │  │  - Entry logging UI                              │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  Registration Form                               │   │  │
│  │  │  - Person details (name, phone, type, flat)      │   │  │
│  │  │  - Face camera capture                           │   │  │
│  │  │  - Submit to backend                             │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  │  ┌──────────────────────────────────────────────────┐   │  │
│  │  │  face-api.js (runs in browser)                   │   │  │
│  │  │  - Detects face in video stream                  │   │  │
│  │  │  - Extracts 128D face descriptor                 │   │  │
│  │  │  - Calculates face-to-face distance              │   │  │
│  │  └──────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                            ↓ HTTP API                           │
└─────────────────────────────────────────────────────────────────┘
                                │
                ┌───────────────┴───────────────┐
                ↓                               ↓
      ┌──────────────────┐           ┌──────────────────────┐
      │  Next.js Backend │           │ Firebase/Firestore   │
      │  (API Routes)    │◄─────────►│ (Database)           │
      │                  │           │                      │
      │ - /api/register  │           │ Collections:         │
      │ - /api/verify    │           │ - persons            │
      │ - /api/entries   │           │ - entries            │
      │ - /api/search    │           │ - vehicles           │
      │                  │           │                      │
      └──────────────────┘           └──────────────────────┘
                │                           ↓
                │                    ┌──────────────────┐
                │                    │ Firebase Storage │
                │                    │ (Face Images)    │
                │                    └──────────────────┘
                │
      ┌─────────┴──────────┐
      ↓                    ↓
┌──────────────┐    ┌──────────────────┐
│ AWS S3 (v2)  │    │ AWS Rekognition  │
│ (Optional)   │    │ (Future Upgrade) │
└──────────────┘    └──────────────────┘
```

---

## Data Flow Diagrams

### Flow 1: Person Registration

```
User Fill Form
    ↓
User Clicks "Capture Face"
    ↓
Browser Accesses Camera
    ↓
Video Stream Displayed
    ↓
User Clicks "Capture Face" Button
    ↓
┌─────────────────────────────────────────────┐
│ face-api.js runs in Browser (Client-Side)   │
│ 1. Detects face in video frame              │
│ 2. Extracts 128D face descriptor            │
│ 3. Returns descriptor (128 numbers)         │
└─────────────────────────────────────────────┘
    ↓
JavaScript stores descriptor in memory
    ↓
User Clicks "Submit Registration"
    ↓
┌─────────────────────────────────────────────┐
│ HTTP POST to /api/register                  │
│ Data: {                                     │
│   name, phone, category, flat,              │
│   faceDescriptor,                           │
│   faceImage (base64)                        │
│ }                                           │
└─────────────────────────────────────────────┘
    ↓
Backend Receives Request
    ↓
Validate Data
    ↓
Store in Firestore:
  - persons collection
  - Create new document
  - Save all fields
    ↓
Store Face Image in Firebase Storage
    ↓
Return Success + Person ID
    ↓
UI Shows "Successfully Registered!"
```

### Flow 2: Guard Scans Face & Logs Entry

```
Guard Navigates to /guard/dashboard
    ↓
Camera Stream Starts
    ↓
System Loads All Registered Persons from Firestore
    ↓
Guard Clicks "Scan Face"
    ↓
┌─────────────────────────────────────────────────┐
│ face-api.js Runs (Client-Side)                  │
│ 1. Captures current video frame                 │
│ 2. Detects face                                 │
│ 3. Extracts descriptor (128D vector)            │
│ 4. Compares with ALL stored descriptors         │
│ 5. Calculates distance for each match           │
│ 6. Returns best match (lowest distance)         │
└─────────────────────────────────────────────────┘
    ↓
IF distance < 0.6:
    MATCH FOUND ✓
ELSE:
    NO MATCH
    ↓
┌─────────────────────────────────────────────┐
│ If Match Found:                             │
│ - Show Person Details (Name, Category)      │
│ - Display Person Photo                      │
│ - Highlight in Green                        │
│ - Enable "Log Entry" Button                 │
└─────────────────────────────────────────────┘
    ↓
Guard Selects Flat Number from Input
    ↓
Guard Clicks "Log Entry"
    ↓
┌─────────────────────────────────────────────┐
│ HTTP POST to /api/entries                   │
│ Data: {                                     │
│   personId, personName, personCategory,     │
│   associatedFlat, status: "entry",          │
│   verificationMethod: "face",               │
│   accuracy: 0.95                            │
│ }                                           │
└─────────────────────────────────────────────┘
    ↓
Backend Receives Request
    ↓
Create Entry Document in Firestore
    ↓
Return Entry ID + Timestamp
    ↓
UI Shows "Entry Logged!"
    ↓
Recent Entries List Refreshes
    ↓
Guard Can Scan Next Person
```

### Flow 3: Manual Lookup (Face Recognition Failed)

```
Face Recognition Failed (No Match Found)
    ↓
Guard Enters Phone Number
    ↓
Guard Clicks "Search"
    ↓
HTTP GET /api/search?phone=9876543210
    ↓
Backend Queries Firestore:
  where phone == "9876543210"
    ↓
IF Person Found:
    Return Person Details
ELSE:
    Return "Not Found"
    ↓
UI Displays Person or Error
    ↓
IF Found:
    Show Person Card (Like Face Match)
    Guard selects flat
    Guard clicks "Log Entry"
    (Same as Flow 2)
```

---

## Data Structures

### 1. Person Document (Firestore)

```javascript
{
  id: "K9x2mL5nP1q",  // Auto-generated by Firestore
  
  // Basic Info
  name: "Rajesh Kumar",
  phone: "9876543210",
  category: "resident",  // resident | daily-labor | service-worker | vendor | guest
  
  // Association
  associatedFlat: "501",
  purpose: "Home",  // For service workers: "Maid", "Plumber", etc.
  company: "Amazon",  // For vendors
  
  // Face Data (Client-Side Generated)
  faceDescriptor: Float32Array[128],  // 128-dimensional vector
  /*
    Example: [0.234, -0.456, 0.789, ... 128 values total]
    This is the face's "fingerprint" - unique per person
    Generated by face-api.js using deep neural networks
  */
  
  faceImage: "data:image/jpeg;base64,/9j/4AAQSkZJRg...",  // Base64 encoded photo
  
  // Metadata
  registeredAt: Timestamp(2026-08-28 10:30:00),
  registeredBy: "admin"
}
```

### 2. Entry Document (Firestore)

```javascript
{
  id: "K8y3qZ7mL2p",  // Auto-generated
  
  // Person Reference
  personId: "K9x2mL5nP1q",
  personName: "Rajesh Kumar",
  personCategory: "resident",
  
  // Location
  associatedFlat: "501",
  purpose: "Home",
  
  // Timestamp
  entryTime: Timestamp(2026-08-28 10:35:22),
  exitTime: null,  // Set when person exits
  
  // Verification Details
  status: "entry",  // "entry" or "exit"
  verificationMethod: "face",  // "face" | "manual" | "qr"
  accuracy: 0.95,  // Confidence score (0.0 to 1.0)
  
  // Optional
  deviceId: "guard-tablet-1",
  latitude: 19.0176,
  longitude: 72.8479
}
```

### 3. Vehicle Document (Firestore)

```javascript
{
  id: "V4k2mL9nQ5r",
  
  residencyId: "K9x2mL5nP1q",  // Reference to resident
  licensePlate: "MH02AB1234",
  model: "Honda City",
  color: "Silver",
  
  registeredAt: Timestamp(2026-08-28 10:30:00),
  
  // Future: ANPR matching data
  // plateDescriptor: [...],  // ML descriptor for number plate
}
```

---

## Face Recognition Algorithm (Deep Dive)

### How face-api.js Works

```
┌─────────────────────────────────────┐
│ Video Frame (640x480 pixels)        │
│ Raw image data from camera          │
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────────────────────┐
│ Step 1: Face Detection (TinyFaceDetector)               │
│ Input: Raw image                                        │
│ Output: Face bounding box (x, y, width, height)        │
│ Model: Tiny neural network (~240KB)                    │
│ Accuracy: ~95% on good images                          │
└─────────────────────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────────────────────┐
│ Step 2: Face Landmark Detection                         │
│ Input: Face bounding box + image                        │
│ Output: 68 key points (eyes, nose, mouth, jaw, etc.)   │
│ Model: 68-point facial landmark detector                │
│ Purpose: Align face for descriptor extraction           │
└─────────────────────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────────────────────┐
│ Step 3: Face Descriptor Extraction                      │
│ Input: Face image + landmarks                          │
│ Output: 128-dimensional vector (128 numbers)           │
│ Model: ResNet-based deep neural network                │
│ Size: ~28MB, trained on millions of faces              │
│ Purpose: Encode face features into fixed-size vector   │
│                                                         │
│ Example descriptor:                                     │
│ [0.234, -0.456, 0.789, ..., -0.123] (128 values)      │
│                                                         │
│ Key Property: Similar faces → Similar vectors          │
│ Distance between vectors ∝ face similarity             │
└─────────────────────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────────────────────┐
│ Step 4: Face Matching (Euclidean Distance)              │
│                                                         │
│ For each registered person:                            │
│   distance = √[(d1-r1)² + (d2-r2)² + ... (d128-r128)²] │
│                                                         │
│ Where:                                                  │
│   d = descriptor from detected face                     │
│   r = stored descriptor for registered person          │
│                                                         │
│ Distance Interpretation:                               │
│   0.0 = Identical faces (impossible)                   │
│   0.3 = Same person, different angles                  │
│   0.5 = Same person, different lighting               │
│   0.6 = Borderline (our threshold)                    │
│   0.8 = Different people (likely)                      │
│   1.0+ = Completely different                          │
│                                                         │
│ Threshold = 0.6                                        │
│ If distance < 0.6: MATCH ✓                            │
│ If distance ≥ 0.6: NO MATCH ✗                         │
└─────────────────────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────────────────────┐
│ Step 5: Return Best Match                               │
│                                                         │
│ Matched People: []                                      │
│ If (Rajesh's distance = 0.45):                         │
│   Matched[0] = {person: Rajesh, distance: 0.45} ✓      │
│ If (Priya's distance = 0.42):                          │
│   Matched[1] = {person: Priya, distance: 0.42} ✓       │
│ If (Guard's distance = 0.75):                          │
│   Not matched (> 0.6 threshold)                        │
│                                                         │
│ Return: Best match = Priya (0.42 < 0.45)              │
│ Confidence: 95% (1 - 0.42/1.0)                        │
└─────────────────────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────────────────────┐
│ Result: Person Identified + Entry Logged                │
└─────────────────────────────────────────────────────────┘
```

### Accuracy Factors

| Factor | Impact | Mitigation |
|--------|--------|-----------|
| **Lighting** | 🔴 Critical | Install good gate lighting; use flash if needed |
| **Face Angle** | 🟡 High | Ask person to face camera directly |
| **Distance** | 🟡 High | Keep 30-50cm distance |
| **Face Mask** | 🔴 Critical | Ask to remove mask; not applicable for gate |
| **Sunglasses** | 🟡 High | Ask to remove; not applicable for gate |
| **Face Size** | 🟡 High | Adjust camera height for consistent framing |
| **Face Quality** | 🟡 High | Ensure clear registration photo |
| **Model Quality** | 🟢 Low | face-api.js is good; upgrade to AWS for 99%+ |

---

## API Endpoints

### 1. POST /api/register

**Purpose:** Register a new person

**Request:**
```json
{
  "name": "Rajesh Kumar",
  "phone": "9876543210",
  "category": "resident",
  "associatedFlat": "501",
  "purpose": "Home",
  "company": null,
  "faceDescriptor": [0.234, -0.456, ...],  // 128 numbers
  "faceImage": "data:image/jpeg;base64,...",
  "registeredBy": "admin"
}
```

**Response:**
```json
{
  "success": true,
  "personId": "K9x2mL5nP1q",
  "message": "Person registered successfully"
}
```

---

### 2. POST /api/entries

**Purpose:** Log an entry/exit

**Request:**
```json
{
  "personId": "K9x2mL5nP1q",
  "personName": "Rajesh Kumar",
  "personCategory": "resident",
  "associatedFlat": "501",
  "purpose": "Home",
  "status": "entry",
  "verificationMethod": "face",
  "accuracy": 0.95
}
```

**Response:**
```json
{
  "success": true,
  "entryId": "K8y3qZ7mL2p",
  "timestamp": "2026-08-28T10:35:22Z"
}
```

---

### 3. GET /api/entries?hours=24

**Purpose:** Get recent entries

**Response:**
```json
{
  "success": true,
  "entries": [
    {
      "id": "K8y3qZ7mL2p",
      "personName": "Rajesh Kumar",
      "personCategory": "resident",
      "entryTime": "2026-08-28T10:35:22Z",
      "associatedFlat": "501"
    }
  ]
}
```

---

### 4. GET /api/search?phone=9876543210

**Purpose:** Manual lookup by phone

**Response:**
```json
{
  "success": true,
  "person": {
    "id": "K9x2mL5nP1q",
    "name": "Rajesh Kumar",
    "phone": "9876543210",
    "category": "resident",
    "associatedFlat": "501",
    "faceImage": "data:image/jpeg;base64,..."
  }
}
```

---

## Database Queries (Firestore)

### Query 1: Find Person by Phone

```typescript
const q = query(
  collection(db, "persons"),
  where("phone", "==", "9876543210")
);
const result = await getDocs(q);
// Returns: Person document or empty
```

### Query 2: Get Recent Entries (Last 24 Hours)

```typescript
const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
const q = query(
  collection(db, "entries"),
  where("entryTime", ">=", Timestamp.fromDate(cutoff)),
  orderBy("entryTime", "desc"),
  limit(100)
);
const result = await getDocs(q);
// Returns: Array of entries, sorted by time
```

### Query 3: Get Entries for Specific Person

```typescript
const q = query(
  collection(db, "entries"),
  where("personId", "==", "K9x2mL5nP1q"),
  orderBy("entryTime", "desc"),
  limit(50)
);
const result = await getDocs(q);
// Returns: All entries for this person
```

---

## Performance Optimization

### Client-Side (Browser)

| Optimization | Impact | Implementation |
|-------------|--------|-----------------|
| Load models once | 🟢 High | Cache models in memory on first load |
| Lazy load React components | 🟡 Medium | Code splitting with Next.js |
| Compress face images | 🟢 High | JPEG compression 0.8 quality |
| Debounce scan button | 🟢 High | Prevent multiple simultaneous scans |

### Server-Side (Backend)

| Optimization | Impact | Implementation |
|-------------|--------|-----------------|
| Index Firestore queries | 🟢 High | Create composite indexes on phone + category |
| Batch read persons | 🟢 High | Load all persons once, keep in memory |
| Cache recent entries | 🟡 Medium | Redis cache for last 100 entries |
| CDN for face images | 🟡 Medium | Firebase CDN or CloudFlare |

### Database (Firestore)

| Optimization | Impact | Implementation |
|-------------|--------|-----------------|
| Index on phone | 🟢 High | Auto-indexed by Firestore |
| Index on entryTime | 🟢 High | Allows range queries |
| TTL for old entries | 🟡 Medium | Auto-delete entries >6 months old |
| Compression of descriptors | 🟡 Low | Store as binary instead of float array |

---

## Security Considerations

### 1. Face Data Privacy

- **Storage:** Encrypted at rest (Firebase uses AES-256)
- **Transmission:** HTTPS only
- **Deletion:** Auto-delete face images after 90 days
- **Access:** Only authenticated guards can access

### 2. Authentication

- Add Firebase Auth (phone OTP for guards)
- Role-based access (admin, guard, resident)
- Session management (auto-logout after 30 min)

### 3. Audit Trail

- Log every access to face data
- Track who viewed which entries
- Timestamp all operations
- Immutable entry records (can't edit/delete)

### 4. Compliance

- GDPR: Data deletion on request
- CCPA: Transparency on data usage
- India DPA: Clear privacy policy
- Insurance requirements: Meet compliance standards

---

## Scaling Strategy

### Phase 1: Single Society (Kharghar)

- 500-1000 persons
- 10K-15K entries/month
- Firebase free tier sufficient
- Manual backups

### Phase 2: 5-10 Societies (Navi Mumbai)

- 5K-10K persons
- 100K-150K entries/month
- Firestore still sufficient
- Automated daily backups
- Consider caching layer

### Phase 3: 50+ Societies (Mumbai Metro)

- 50K-100K persons
- 1M+ entries/month
- Need dedicated Firestore instances per region
- Redis cache for hot data
- CDN for image delivery
- Sharding strategy for database

### Phase 4: National Scale

- 500K+ persons
- 10M+ entries/month
- Migrate to managed Postgres/MongoDB
- Elasticsearch for searching
- Kafka for event streaming
- Multi-region deployment
- AWS Rekognition for face recognition

---

## Cost Breakdown (MVP - Year 1)

### Infrastructure

| Service | Usage | Cost/Month |
|---------|-------|-----------|
| Firebase Firestore | 50K docs, 100K reads | ₹200 |
| Firebase Storage | 100GB images | ₹300 |
| Vercel (frontend) | 1GB bandwidth | ₹200 |
| AWS Rekognition (v2) | 10K calls | ₹2,000 |
| **Total** | | **₹2,700** |

### Development

| Item | Cost |
|------|------|
| Your time (100 hrs @ ₹500/hr) | ₹50,000 |
| Camera hardware | ₹5,000 |
| Domain (.com) | ₹500/year |
| **Total** | **₹55,500** |

### Total Year 1: ₹87,700 (including your time)

### Revenue (15 societies @ ₹8K/month)

| Month | Societies | MRR | Annual |
|-------|-----------|-----|--------|
| 1-3 | 1 | ₹5K | ₹15K |
| 4-6 | 5 | ₹30K | ₹110K |
| 7-9 | 10 | ₹70K | ₹330K |
| 10-12 | 15 | ₹120K | ₹700K |

**Year 1 Revenue: ₹7L | Year 1 Cost: ₹1.5L | Year 1 Profit: ₹5.5L**

---

## Future Enhancements

### Short-Term (Month 3-6)

1. **Vehicle Registration**
   - ANPR (Automatic Number Plate Recognition)
   - RFID/FASTag integration
   - Auto-entry when registered vehicle detected

2. **Guest Management**
   - Residents pre-approve guests
   - Timed access (valid for 2 hours)
   - SMS notification to resident

3. **Parcel Tracking**
   - Barcode scanning
   - Delivery photo capture
   - Proof of delivery

4. **Analytics Dashboard**
   - Entry/exit trends
   - Peak times
   - Most frequent visitors
   - Entry method statistics

### Medium-Term (Month 6-12)

1. **Advanced Matching**
   - Multi-angle face recognition
   - Age/gender verification (anti-spoofing)
   - Liveness detection (prevent photo attacks)

2. **Service Staff Verification**
   - Background checks integration
   - ID verification
   - License/certification upload

3. **Notifications**
   - SMS alerts for specific people
   - WhatsApp notifications for residents
   - Emergency alerts for security

4. **Mobile Apps**
   - Guard app (offline mode)
   - Resident app (guest invitations)
   - Admin dashboard

### Long-Term (Year 2+)

1. **AI-Powered Insights**
   - Behavioral anomalies
   - Suspicious pattern detection
   - Predictive alerts

2. **Integration Ecosystem**
   - Smart lock integration
   - Building management system API
   - CRM/HRM systems

3. **Multi-Property Management**
   - Manage 100+ societies from one platform
   - Unified identity across properties
   - Cross-property visitor tracking

4. **Monetization Expansion**
   - White-label offering for builders
   - Data analytics for real estate
   - Insurance partnership

---

## Conclusion

GateSure is a **technically sound, scalable, and profitable** business with a clear path to ₹1L+ MRR. The MVP is achievable in 10 weeks, and the business model supports sustainable growth.

**Key Success Factors:**
1. Execute fast (MVP by Week 10)
2. Validate with real users (Kharghar)
3. Gather feedback & iterate
4. Scale with repeatable playbook
5. Keep focus on core value (security + speed)

**Good luck building! 🚀**
