# Face-API.js Models - Correct Setup Guide

## ⚠️ The Problem

The exact models don't exist as standalone downloads. You need to either:
1. **Option A:** Clone the face-api repository and copy models
2. **Option B:** Download from a CDN (easiest)
3. **Option C:** Build from source

---

## ✅ Option A: Clone Repository & Copy Models (EASIEST)

### Step 1: Clone face-api repository

```bash
# Navigate to a temp directory
cd ~/Downloads

# Clone the repository
git clone https://github.com/vladmandic/face-api.js.git

cd face-api.js
```

### Step 2: Find the models folder

```bash
# In the cloned repo, navigate to models
cd model

# You'll see these files:
# ├── age_gender_model-shard1
# ├── age_gender_model-weights_manifest.json
# ├── face_landmark_68_model-shard1
# ├── face_landmark_68_model-weights_manifest.json
# ├── face_recognition_model-shard1
# ├── face_recognition_model-weights_manifest.json
# ├── tiny_face_detector_model-shard1
# ├── tiny_face_detector_model-weights_manifest.json
# └── README.md

ls -la
```

### Step 3: Copy to your project

```bash
# Navigate to your GateSure project
cd /path/to/gatesure

# Create public/models directory if not exists
mkdir -p public/models

# Copy ALL model files from face-api.js/model to public/models
cp ~/Downloads/face-api.js/model/* public/models/

# Verify
ls -la public/models/
```

**Expected output:**
```
-rw-r--r--  age_gender_model-shard1
-rw-r--r--  age_gender_model-weights_manifest.json
-rw-r--r--  face_landmark_68_model-shard1
-rw-r--r--  face_landmark_68_model-weights_manifest.json
-rw-r--r--  face_recognition_model-shard1
-rw-r--r--  face_recognition_model-weights_manifest.json
-rw-r--r--  tiny_face_detector_model-shard1
-rw-r--r--  tiny_face_detector_model-weights_manifest.json
```

---

## ✅ Option B: Download from CDN (RECOMMENDED FOR MVP)

This is the easiest - no cloning needed.

### Update your faceRecognition.ts

Instead of loading from local files, load from CDN:

```typescript
// lib/faceRecognition.ts

import * as faceapi from 'face-api.js';

const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';

let modelsLoaded = false;

export async function loadModels() {
  if (modelsLoaded) return;
  
  try {
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
      faceapi.nets.ageGenderNet.loadFromUri(MODEL_URL),
    ]);
    console.log('✓ Face models loaded from CDN');
    modelsLoaded = true;
  } catch (error) {
    console.error('Failed to load face models:', error);
    throw new Error('Face recognition models failed to load from CDN');
  }
}

// Rest of the code stays the same...
```

**Advantages:**
- ✅ No need to download/store large files
- ✅ Models cached by CDN automatically
- ✅ Easier deployment
- ✅ Works immediately

**Disadvantages:**
- ❌ Requires internet connection
- ❌ First load is slightly slower (~2-3 seconds)
- ❌ Depends on CDN availability

**Recommendation for MVP:** Use Option B (CDN)

---

## ✅ Option C: Download Individual Files Manually

If you prefer local files but don't want to clone git:

### Step 1: Find correct URLs

The actual CDN URLs for each model file:

```
Base: https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/

Age/Gender Model:
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/age_gender_model-shard1
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/age_gender_model-weights_manifest.json

Face Landmark Model:
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/face_landmark_68_model-shard1
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/face_landmark_68_model-weights_manifest.json

Face Recognition Model:
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/face_recognition_model-shard1
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/face_recognition_model-weights_manifest.json

Tiny Face Detector Model:
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/tiny_face_detector_model-shard1
- https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/tiny_face_detector_model-weights_manifest.json
```

### Step 2: Create download script

Create a file called `download-models.sh`:

```bash
#!/bin/bash

# Create models directory
mkdir -p public/models

# Download each file
BASE_URL="https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/"

echo "Downloading face-api models..."

# Age/Gender Model
curl -o public/models/age_gender_model-shard1 "${BASE_URL}age_gender_model-shard1"
curl -o public/models/age_gender_model-weights_manifest.json "${BASE_URL}age_gender_model-weights_manifest.json"

# Face Landmark Model
curl -o public/models/face_landmark_68_model-shard1 "${BASE_URL}face_landmark_68_model-shard1"
curl -o public/models/face_landmark_68_model-weights_manifest.json "${BASE_URL}face_landmark_68_model-weights_manifest.json"

# Face Recognition Model
curl -o public/models/face_recognition_model-shard1 "${BASE_URL}face_recognition_model-shard1"
curl -o public/models/face_recognition_model-weights_manifest.json "${BASE_URL}face_recognition_model-weights_manifest.json"

# Tiny Face Detector Model
curl -o public/models/tiny_face_detector_model-shard1 "${BASE_URL}tiny_face_detector_model-shard1"
curl -o public/models/tiny_face_detector_model-weights_manifest.json "${BASE_URL}tiny_face_detector_model-weights_manifest.json"

echo "✓ Models downloaded successfully"
ls -lh public/models/
```

### Step 3: Run the script

```bash
chmod +x download-models.sh
./download-models.sh
```

---

## 🎯 RECOMMENDED: Use Option B (CDN)

Update your `lib/faceRecognition.ts` to load from CDN:

```typescript
'use client';

import * as faceapi from 'face-api.js';

// Use CDN instead of local files
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';

let modelsLoaded = false;

export async function loadModels() {
  if (modelsLoaded) return;
  
  try {
    console.log('Loading face recognition models...');
    
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
      faceapi.nets.ageGenderNet.loadFromUri(MODEL_URL),
    ]);
    
    console.log('✓ Face models loaded successfully from CDN');
    modelsLoaded = true;
  } catch (error) {
    console.error('Failed to load face models:', error);
    throw new Error('Face recognition models failed to load. Check internet connection.');
  }
}

export async function captureAndExtractFace(
  videoElement: HTMLVideoElement
): Promise<Float32Array | null> {
  try {
    const detections = await faceapi
      .detectSingleFace(videoElement, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (!detections) {
      return null;
    }

    return detections.descriptor;
  } catch (error) {
    console.error('Face detection error:', error);
    return null;
  }
}

export function compareFaceDescriptors(
  descriptor1: Float32Array,
  descriptor2: Float32Array,
  threshold: number = 0.6
): number {
  if (!descriptor1 || !descriptor2) return 1;

  const distance = faceapi.euclideanDistance(
    Array.from(descriptor1),
    Array.from(descriptor2)
  );

  return distance;
}

export function isFaceMatch(
  distance: number,
  threshold: number = 0.6
): boolean {
  return distance < threshold;
}

export async function capturePhotoBase64(
  videoElement: HTMLVideoElement
): Promise<string> {
  const canvas = document.createElement('canvas');
  canvas.width = videoElement.videoWidth;
  canvas.height = videoElement.videoHeight;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Failed to get canvas context');

  ctx.drawImage(videoElement, 0, 0);

  return canvas.toDataURL('image/jpeg', 0.8);
}
```

---

## ✅ Verification Checklist

### If Using CDN (Option B - Recommended):

```bash
# Just make sure your code has:
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';

# Then test:
# 1. Run npm run dev
# 2. Open browser console (F12)
# 3. Go to /register/person
# 4. Click "Capture Face"
# 5. Should see in console: "✓ Face models loaded successfully from CDN"
# 6. Camera should appear
# 7. Try capturing a face
```

### If Using Local Files (Option A):

```bash
# Verify files exist
ls -la public/models/

# Should show:
# ├── age_gender_model-shard1 (~8MB)
# ├── age_gender_model-weights_manifest.json
# ├── face_landmark_68_model-shard1 (~10MB)
# ├── face_landmark_68_model-weights_manifest.json
# ├── face_recognition_model-shard1 (~28MB)
# ├── face_recognition_model-weights_manifest.json
# ├── tiny_face_detector_model-shard1 (~1.4MB)
# └── tiny_face_detector_model-weights_manifest.json
```

---

## 🚨 Troubleshooting

### Problem: "Failed to load face models"

**Cause 1: Wrong CDN URL**
```typescript
// ❌ WRONG
const MODEL_URL = '/models/';

// ✅ CORRECT
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';
```

**Cause 2: Missing trailing slash**
```typescript
// ❌ WRONG
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models';

// ✅ CORRECT
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';
```

**Cause 3: Internet connection issue**
```bash
# Test if CDN is reachable
curl -I https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/tiny_face_detector_model-shard1

# Should return: HTTP/1.1 200 OK
```

### Problem: "Models load but face detection doesn't work"

```bash
# Check browser console (F12 > Console tab)
# Look for any errors about model sizes or versions

# Try clearing browser cache:
# Chrome: Ctrl+Shift+Delete
# Firefox: Ctrl+Shift+Delete
# Safari: Develop > Empty Web Storage

# Then reload page
```

### Problem: "Camera works but face not detected"

```bash
# Not a model problem - likely:
1. Poor lighting
2. Face too small in frame
3. Face at wrong angle
4. Camera resolution too low

# Solutions:
1. Add more light
2. Move closer to camera (30-50cm)
3. Face camera directly
4. Try different camera
```

---

## 📊 Model File Sizes

**Total size: ~47MB**

```
age_gender_model-shard1              ~8.0 MB
face_landmark_68_model-shard1        ~10.0 MB
face_recognition_model-shard1        ~28.0 MB
tiny_face_detector_model-shard1      ~1.4 MB
────────────────────────────────────────────
TOTAL                                ~47.4 MB

If storing locally (Option A):
- First load: 47 MB download
- Subsequent loads: Cached (instant)
- Deployment: +47 MB to your build

If using CDN (Option B):
- First load: CDN cached (2-3 sec)
- Subsequent loads: Browser cache (instant)
- Deployment: 0 MB to your build
```

---

## 🎯 FINAL RECOMMENDATION

### For MVP (Week 1-10):
**USE OPTION B (CDN)**

```typescript
// lib/faceRecognition.ts
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';
```

**Why:**
- ✅ Simplest setup (no downloads needed)
- ✅ Faster deployment (smaller build)
- ✅ Works immediately
- ✅ No storage headache

### For Production (Month 3+):
**MIGRATE TO OPTION A (Local Files)**

**Why:**
- ✅ Guaranteed availability
- ✅ Offline capability (future)
- ✅ Full control
- ✅ No CDN dependency

---

## Step-by-Step Setup (CDN Method - FASTEST)

### 1. No extra setup needed
Your code already has:
```typescript
const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';
```

### 2. Just run
```bash
npm run dev
```

### 3. Test
```
Open: http://localhost:3000/register/person
Click: "Capture Face"
Result: Camera appears, models load from CDN
```

**Done! You're ready to test face recognition.**

---

## Quick Reference

```bash
# Option A (Clone):
git clone https://github.com/vladmandic/face-api.js.git
cp face-api.js/model/* gatesure/public/models/

# Option B (CDN - RECOMMENDED):
# Update lib/faceRecognition.ts with:
# const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@latest/dist/models/';

# Option C (Script download):
# bash download-models.sh
```

**Pick ONE. Recommendation: Option B (CDN).**

Done! ✅
