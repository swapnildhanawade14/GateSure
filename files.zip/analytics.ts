# GateSure Analytics Dashboard - Complete Implementation

## Why Analytics Dashboard is Critical for MVP

**This is THE differentiator that sells societies on paying ₹8-15K/month.**

When you present to society secretaries:
- "We log every entry" ✓ Good
- "We reduce gate delays by 80%" ✓ Good  
- **"Here's exactly who entered your building, when, and why" ✓ POWERFUL**

Analytics provides:
1. **Security proof:** "All 47 vendors entered via face recognition yesterday"
2. **Operational visibility:** "Peak entries: 7-8 AM (42 people), 1-2 PM (28 people)"
3. **Data-driven decisions:** "Service staff visit patterns show concentrated hours"
4. **ROI justification:** "Time saved per day: 4.2 hours of guard time"
5. **Compliance:** "Complete audit trail for incidents"

---

## File 1: lib/analytics.ts - Analytics Data Queries

```typescript
import {
  collection,
  query,
  where,
  getDocs,
  orderBy,
  Timestamp,
} from 'firebase/firestore';
import { db } from './firebase';
import { Entry, Person } from './types';

// Get entries for a date range
export async function getEntriesByDateRange(
  startDate: Date,
  endDate: Date
): Promise<Entry[]> {
  try {
    const q = query(
      collection(db, 'entries'),
      where('entryTime', '>=', Timestamp.fromDate(startDate)),
      where('entryTime', '<=', Timestamp.fromDate(endDate)),
      orderBy('entryTime', 'asc')
    );

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Entry[];
  } catch (error) {
    console.error('Error fetching entries by date:', error);
    return [];
  }
}

// Get entry/exit trends by hour
export async function getEntryTrendsByHour(
  entries: Entry[]
): Promise<{ hour: number; count: number; label: string }[]> {
  const hourCounts = new Map<number, number>();

  // Initialize all hours with 0
  for (let i = 0; i < 24; i++) {
    hourCounts.set(i, 0);
  }

  // Count entries by hour
  entries.forEach((entry) => {
    const date = entry.entryTime.toDate?.() || new Date(entry.entryTime);
    const hour = date.getHours();
    hourCounts.set(hour, (hourCounts.get(hour) || 0) + 1);
  });

  // Convert to array format for chart
  const trends = Array.from(hourCounts.entries())
    .map(([hour, count]) => ({
      hour,
      count,
      label: `${hour.toString().padStart(2, '0')}:00`,
    }))
    .sort((a, b) => a.hour - b.hour);

  return trends;
}

// Get peak hours (top 3 busiest hours)
export async function getPeakHours(
  entries: Entry[]
): Promise<{ hour: string; count: number }[]> {
  const trends = await getEntryTrendsByHour(entries);
  return trends
    .sort((a, b) => b.count - a.count)
    .slice(0, 3)
    .map((t) => ({
      hour: t.label,
      count: t.count,
    }));
}

// Get most frequent visitors
export async function getMostFrequentVisitors(
  entries: Entry[],
  limit: number = 10
): Promise<
  {
    personId: string;
    personName: string;
    personCategory: string;
    visitCount: number;
  }[]
> {
  const visitorMap = new Map<
    string,
    {
      personId: string;
      personName: string;
      personCategory: string;
      count: number;
    }
  >();

  entries.forEach((entry) => {
    const key = entry.personId;
    if (visitorMap.has(key)) {
      const visitor = visitorMap.get(key)!;
      visitor.count += 1;
    } else {
      visitorMap.set(key, {
        personId: entry.personId,
        personName: entry.personName,
        personCategory: entry.personCategory,
        count: 1,
      });
    }
  });

  return Array.from(visitorMap.values())
    .sort((a, b) => b.count - a.count)
    .slice(0, limit)
    .map((v) => ({
      personId: v.personId,
      personName: v.personName,
      personCategory: v.personCategory,
      visitCount: v.count,
    }));
}

// Get entry method statistics
export async function getEntryMethodStats(
  entries: Entry[]
): Promise<{ method: string; count: number; percentage: number }[]> {
  const methodMap = new Map<string, number>();

  entries.forEach((entry) => {
    const method = entry.verificationMethod || 'unknown';
    methodMap.set(method, (methodMap.get(method) || 0) + 1);
  });

  const total = entries.length;
  const stats = Array.from(methodMap.entries())
    .map(([method, count]) => ({
      method: method.charAt(0).toUpperCase() + method.slice(1),
      count,
      percentage: (count / total) * 100,
    }))
    .sort((a, b) => b.count - a.count);

  return stats;
}

// Get visitor category breakdown
export async function getVisitorCategoryBreakdown(
  entries: Entry[]
): Promise<{ category: string; count: number; percentage: number }[]> {
  const categoryMap = new Map<string, number>();

  entries.forEach((entry) => {
    const category = entry.personCategory || 'unknown';
    categoryMap.set(category, (categoryMap.get(category) || 0) + 1);
  });

  const total = entries.length;
  const breakdown = Array.from(categoryMap.entries())
    .map(([category, count]) => ({
      category: category
        .split('-')
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' '),
      count,
      percentage: (count / total) * 100,
    }))
    .sort((a, b) => b.count - a.count);

  return breakdown;
}

// Get entries by flat
export async function getEntriesByFlat(
  entries: Entry[]
): Promise<{ flat: string; count: number }[]> {
  const flatMap = new Map<string, number>();

  entries.forEach((entry) => {
    if (entry.associatedFlat) {
      const flat = entry.associatedFlat;
      flatMap.set(flat, (flatMap.get(flat) || 0) + 1);
    }
  });

  return Array.from(flatMap.entries())
    .map(([flat, count]) => ({
      flat,
      count,
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 15); // Top 15 flats
}

// Calculate summary statistics
export async function getSummaryStats(entries: Entry[]): Promise<{
  totalEntries: number;
  uniqueVisitors: number;
  averageEntriesPerDay: number;
  averageEntriesPerHour: number;
  timeGuardSavedHours: number;
  mostCommonCategory: string;
}> {
  const uniqueVisitors = new Set(entries.map((e) => e.personId)).size;

  // Calculate days covered
  const dates = new Set<string>();
  entries.forEach((entry) => {
    const date = entry.entryTime.toDate?.() || new Date(entry.entryTime);
    dates.add(date.toDateString());
  });
  const daysCovered = Math.max(dates.size, 1);

  // Calculate categories
  const categoryMap = new Map<string, number>();
  entries.forEach((entry) => {
    const category = entry.personCategory || 'unknown';
    categoryMap.set(category, (categoryMap.get(category) || 0) + 1);
  });
  const mostCommonCategory = Array.from(categoryMap.entries()).sort(
    (a, b) => b[1] - a[1]
  )[0]?.[0] || 'unknown';

  // Time savings: assume 2 min saved per entry vs manual (10 sec face vs 2.5 min manual)
  const timePerEntrySavedMinutes = 2;
  const totalMinutesSaved = entries.length * timePerEntrySavedMinutes;
  const timeGuardSavedHours = totalMinutesSaved / 60;

  return {
    totalEntries: entries.length,
    uniqueVisitors,
    averageEntriesPerDay: Math.round(entries.length / daysCovered),
    averageEntriesPerHour: Math.round(entries.length / (daysCovered * 24)),
    timeGuardSavedHours: Math.round(timeGuardSavedHours * 10) / 10,
    mostCommonCategory,
  };
}

// Get daily entry counts
export async function getDailyEntryCounts(
  entries: Entry[]
): Promise<{ date: string; count: number }[]> {
  const dateMap = new Map<string, number>();

  entries.forEach((entry) => {
    const date = entry.entryTime.toDate?.() || new Date(entry.entryTime);
    const dateStr = date.toISOString().split('T')[0]; // YYYY-MM-DD
    dateMap.set(dateStr, (dateMap.get(dateStr) || 0) + 1);
  });

  return Array.from(dateMap.entries())
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
}
